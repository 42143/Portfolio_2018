import React from 'luy';
import ReactDOM from 'luy';
import App from './App';

ReactDOM.render(
    <div>
        <App />
    </div>,
    document.getElementById('root')
);