# React-awesome-resume

特色
-----
本网页由自制类React框架Luy制作，除了react的babel之外，Luy核心代码完全是由自己写成（你可以无缝切回react


项目预览
-------
- [预览地址](http://htmlpreview.github.io/?https://github.com/215566435/React-awesome-resume/blob/master/build/index.html)


如何开始？
-------
```
git clone git@github.com:215566435/React-awesome-resume.git
cd React-awesome-resume
npm install
npm run dev
```

然后访问：
```
http://127.0.0.1:8080/
```

如何生成生产环境项目进行部署？？
-------
```
git clone git@github.com:215566435/React-awesome-resume.git
cd React-awesome-resume
npm install
npm run build

```

然后你复制目录build下的
```
- bundle.js
- index.html
```
到你的服务器中去